import { ExternalLink } from "lucide-react";
import Link from "next/link";

import { buildPageMetadata } from "@/lib/seo";

const docsLinks = [
  {
    title: "First Live Swap Guide",
    description: "Trader walkthrough: connect a wallet, set trustlines, set slippage, and confirm your first swap.",
    href: "/guide",
    external: false,
  },
  {
    title: "Documentation Index",
    description: "Browse the main OrynRoute documentation directory.",
    href: "https://github.com/OrynRoute/OrynRoute/tree/main/docs",
    external: true,
  },
  {
    title: "API Reference",
    description: "Review REST API routes, schemas, websocket docs, and integration guidance.",
    href: "https://github.com/OrynRoute/OrynRoute/tree/main/docs/api",
    external: true,
  },
  {
    title: "Developer Guide",
    description: "Set up the frontend, indexer, testing flow, and wallet integration locally.",
    href: "https://github.com/OrynRoute/OrynRoute/tree/main/docs/development",
    external: true,
  },
  {
    title: "Contract Docs",
    description: "Read contract deployment, testing, router interface, and gas benchmark notes.",
    href: "https://github.com/OrynRoute/OrynRoute/tree/main/docs/contracts",
    external: true,
  },
] as const;

export const metadata = buildPageMetadata({
  title: "Docs",
  description:
    "OrynRoute docs for the Stellar DEX aggregator API, cross-chain CCTP, development, and contracts.",
  path: "/docs",
});

export default function DocsPage() {
  return (
    <main className="min-h-[calc(100vh-80px)] px-4 py-10 sm:px-6 lg:px-8">
      <div className="container mx-auto max-w-5xl">
        <div className="mb-8 space-y-2">
          <p className="text-sm font-medium uppercase text-muted-foreground">
            Documentation
          </p>
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
            OrynRoute Docs
          </h1>
          <p className="max-w-2xl text-lg text-muted-foreground">
            Jump into the project guides, API references, and contract documentation
            hosted in the OrynRoute repository.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {docsLinks.map((link) => {
            const className =
              "rounded-lg border bg-card p-5 text-card-foreground transition-colors hover:border-primary/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2";
            const content = (
              <>
                <span className="mb-3 flex items-center justify-between gap-3">
                  <span className="text-base font-semibold">{link.title}</span>
                  {link.external ? (
                    <ExternalLink className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                  ) : null}
                </span>
                <span className="block text-sm leading-6 text-muted-foreground">
                  {link.description}
                </span>
              </>
            );

            if (link.external) {
              return (
                <a
                  key={link.href}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={className}
                >
                  {content}
                </a>
              );
            }

            return (
              <Link key={link.href} href={link.href} className={className}>
                {content}
              </Link>
            );
          })}
        </div>
      </div>
    </main>
  );
}
