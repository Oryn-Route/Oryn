//! Stellar-Native Order Flow Auction (OFA).
//!
//! The auction pool that orders "sell one asset, receive another, elsewhere"
//! without ever broadcasting the user transaction. Users submit
//! signed-but-unbroadcast *intents*; registered solvers (bonded on either the
//! Stellar Soroban registry or the Solana Anchor registry mirror) compete for
//! the best fill during a short off-chain auction; the winning quote is marked
//! as a commitment and must be settled before the intent deadline or the
//! solver's bond is slashed.
//!
//! The Soroban/Solana on-chain registries store bonds and admin/slash state.
//! The API keeps an *off-chain projection* of registrations + the auction
//! rounds/quotes — see [`store`] — and the coordinator in [`auction`] enforces
//! the 2–3 second window and best-quote selection.

pub mod auction;
pub mod store;

pub use auction::{AuctionConfig, AuctionCoordinator, BestQuoteError, BEST_QUOTE_PUBLIC_VIEW};
pub use store::{OpaStore, PgOpaStore};

/// HTTP header a solver sends to authenticate quote submissions.
pub const SOLVER_ID_HEADER: &str = "x-solver-id";
/// HTTP header carrying the solver API key (compared against a stored SHA-256).
pub const SOLVER_KEY_HEADER: &str = "x-solver-key";