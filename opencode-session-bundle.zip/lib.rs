//! OrynRoute Indexer
//!
//! This crate provides the indexing service for SDEX orderbooks and Soroban AMM pools.

pub mod activity;
pub mod amm;
pub mod asset_metadata;
pub mod config;
pub mod db;
pub mod deduplication;
pub mod error;
pub mod horizon;
pub mod metrics;
pub mod models;
pub mod partition;
pub mod reconciliation;
pub mod shutdown;

pub mod sdex;
pub mod soroban;
pub mod telemetry;

use crate::reconciliation::BackfillManager;
use sqlx::PgPool;

pub use deduplication::{
    DeduplicationConfig, DeduplicationResult, DeduplicatorState, DeduplicatorStats,
    EventDeduplicator, EventStatus, IdempotencyKey, OrderingStrategy, ProcessedEvent,
    SequenceError, StreamState,
};

/// Indexer service
pub struct Indexer {
    backfill_manager: Option<BackfillManager>,
}

impl Indexer {
    /// Create a new indexer instance
    pub fn new(pool: PgPool) -> Self {
        Self {
            backfill_manager: Some(BackfillManager::new(pool)),
        }
    }

    /// Access the backfill manager
    pub fn backfill(&self) -> Option<&BackfillManager> {
        self.backfill_manager.as_ref()
    }
}
