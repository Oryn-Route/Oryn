//! OrynRoute API Server
//!
//! Provides REST API endpoints for price quotes and orderbook data.

pub mod admin_audit;
pub mod audit;
pub mod broadcast;
pub mod budget;
pub mod cache;
pub mod cctp;
pub mod compression;
pub mod consistency_guard;
pub mod dependency_health;
pub mod docs;
pub mod env_profile;
pub mod error;
pub mod exactlyonce;
pub mod graph;
pub mod handlers;
pub mod health_scheduler;
pub mod indexer_lag;
pub mod kill_switch;
pub mod liquidity_alerts;
pub mod load_test;
pub mod metrics;
pub mod middleware;
pub mod models;
pub mod ofa;
pub mod ordering;
pub mod purger;
pub mod reconciliation;
pub mod regions;
pub mod replay;
pub mod routes;
pub mod serialization;
pub mod server;
pub mod shutdown;
pub mod simulation;
pub mod state;
pub mod swap;
pub mod telemetry;
pub mod tracing_config;
pub mod webhooks;
pub mod worker;

pub use cache::is_redis_infrastructure_error;
pub use cache::{CacheHealthStatus, CacheLookupOutcome, CacheManager, CacheResult};
pub use docs::ApiDoc;
pub use error::{ApiError, Result};
pub use exactlyonce::{DedupeLedger, ExactlyOnceError, RequestIdentity};
pub use purger::PurgerConfig;
pub use server::{Server, ServerConfig};
pub use state::AppState;
pub use tracing_config::{TraceContext, TracingConfig};
