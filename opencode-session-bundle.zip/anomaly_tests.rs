use chrono::Utc;
use orynroute_routing::health::anomaly::{AnomalyConfig, LiquidityAnomalyDetector};
use orynroute_routing::optimizer::HybridOptimizer;
use orynroute_routing::pathfinder::LiquidityEdge;
use orynroute_routing::pathfinder::PathfinderConfig;
use orynroute_routing::policy::RoutingPolicy;

#[test]
fn test_anomaly_detection_integration() {
    let config = AnomalyConfig {
        reserve_delta_threshold: 0.5,
        depth_collapse_threshold: 0.8,
        alert_threshold: 0.7,
        stale_read_is_anomaly: false,
        ..Default::default()
    };

    let mut detector = LiquidityAnomalyDetector::new(config);

    // 1. Normal scenario
    let venue_ref = "amm:XLM_USDC";
    let res1 = detector.update_and_detect(venue_ref, Some((1000, 1000)), None, Some(Utc::now()));

    assert!(res1.score == 0.0);

    // 2. Small shift (20%) - should not be anomalous
    let res2 = detector.update_and_detect(venue_ref, Some((1200, 1200)), None, Some(Utc::now()));

    assert!(res2.score < 0.7);
    assert!(!detector.is_anomalous(&res2));

    // 3. Large shift (70%) - should be anomalous
    let res3 = detector.update_and_detect(venue_ref, Some((300, 300)), None, Some(Utc::now()));

    assert!(res3.score >= 0.7);
    assert!(detector.is_anomalous(&res3));
    assert!(!res3.reasons.is_empty());
}

#[test]
fn test_optimizer_flags_anomalies() {
    let optimizer = HybridOptimizer::new(PathfinderConfig::default());

    let edges = vec![
        LiquidityEdge {
            from: "XLM".to_string(),
            to: "USDC".to_string(),
            venue_type: "amm".to_string(),
            venue_ref: "anomalous_pool".to_string(),
            liquidity: 10_000_000_000,
            price: 1.0,
            fee_bps: 30,
            ..Default::default()
        },
        LiquidityEdge {
            from: "XLM".to_string(),
            to: "USDC".to_string(),
            venue_type: "sdex".to_string(),
            venue_ref: "healthy_offer".to_string(),
            liquidity: 10_000_000_000,
            price: 1.01,
            fee_bps: 20,
            ..Default::default()
        },
    ];

    let routing_policy = RoutingPolicy::default();
    let result = optimizer
        .find_optimal_routes("XLM", "USDC", &edges, 100_000_000, &routing_policy)
        .unwrap();

    assert!(result.metrics.hop_count >= 1);
    assert_eq!(result.metrics.anomaly_score, 0.0);
    assert!(result.metrics.anomaly_reasons.is_empty());
}
