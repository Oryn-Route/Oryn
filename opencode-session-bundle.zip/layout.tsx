import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Settings | OrynRoute',
  description:
    'Customize your OrynRoute experience with theme, language, and notification settings.',
  openGraph: {
    title: 'Settings | OrynRoute',
    description: 'Personalize your OrynRoute interface and preferences.',
    type: 'website',
  },
};

export default function SettingsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
