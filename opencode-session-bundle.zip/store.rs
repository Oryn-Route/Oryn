//! Postgres-backed OFA store.
//!
//! Amounts are persisted as decimal strings (see migration
//! `20260910_ofa_intents.sql`) and parsed to [`rust_decimal::Decimal`] only
//! when ordering bids, so the database never sees floats and the wire never
//! sees numeric types.

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use sha2::{Digest, Sha256};
use sqlx::{FromRow, PgPool};
use uuid::Uuid;

use crate::models::{IntentStatus, RoundStatus, SolverStatus};

/// Pure metric/value helpers that do not touch the database.
pub fn hash_api_key(api_key: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(api_key.as_bytes());
    hex::encode(hasher.finalize())
}

/// New-intent payload accepted by [`OpaStore::create_intent`].
#[derive(Debug, Clone)]
pub struct NewIntent {
    pub intent_id: Uuid,
    pub user_address: String,
    pub from_asset: String,
    pub from_asset_canonical: String,
    pub from_chain: String,
    pub from_amount: String,
    pub to_asset: String,
    pub to_asset_canonical: String,
    pub to_chain: String,
    pub to_address: String,
    pub deadline: DateTime<Utc>,
    pub min_output: String,
    pub signature: Option<String>,
    pub nonce: i64,
}

/// New solver registration payload.
#[derive(Debug, Clone)]
pub struct NewSolver {
    pub solver_id: Uuid,
    pub name: String,
    pub home_chain: String,
    pub bond_address: String,
    pub bond_asset: String,
    pub bond_amount: String,
    pub api_key_hash: String,
}

/// New quote payload.
#[derive(Debug, Clone)]
pub struct NewQuote {
    pub quote_id: Uuid,
    pub round_id: Uuid,
    pub intent_id: Uuid,
    pub solver_id: Uuid,
    pub fill_amount: String,
    pub execution_path: Option<String>,
    pub quote_signature: String,
}

#[derive(Debug, Clone, FromRow)]
pub struct IntentRow {
    pub intent_id: Uuid,
    pub user_address: String,
    pub from_asset: String,
    pub from_asset_canonical: String,
    pub from_chain: String,
    pub from_amount: String,
    pub to_asset: String,
    pub to_asset_canonical: String,
    pub to_chain: String,
    pub to_address: String,
    pub deadline: DateTime<Utc>,
    pub min_output: String,
    pub signature: Option<String>,
    pub nonce: i64,
    pub status: String,
    pub cancel_reason: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl IntentRow {
    pub fn status(&self) -> IntentStatus {
        IntentStatus::from_str(&self.status).unwrap_or(IntentStatus::Pending)
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct SolverRow {
    pub solver_id: Uuid,
    pub name: String,
    pub home_chain: String,
    pub bond_address: String,
    pub bond_asset: String,
    pub bond_amount: String,
    pub status: String,
    pub registered_at: DateTime<Utc>,
    pub last_heartbeat_at: Option<DateTime<Utc>>,
    pub api_key_hash: String,
}

impl SolverRow {
    pub fn status(&self) -> SolverStatus {
        SolverStatus::from_str(&self.status).unwrap_or(SolverStatus::Suspended)
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct RoundRow {
    pub round_id: Uuid,
    pub intent_id: Uuid,
    pub opened_at: DateTime<Utc>,
    pub closes_at: DateTime<Utc>,
    pub status: String,
    pub winner_solver_id: Option<Uuid>,
    pub winner_quote_id: Option<Uuid>,
    pub settled_tx_hash: Option<String>,
    pub settled_chain: Option<String>,
    pub settled_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
}

impl RoundRow {
    pub fn status(&self) -> RoundStatus {
        RoundStatus::from_str(&self.status).unwrap_or(RoundStatus::ExpiredNoWinner)
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct QuoteRow {
    pub quote_id: Uuid,
    pub round_id: Uuid,
    pub intent_id: Uuid,
    pub solver_id: Uuid,
    pub fill_amount: String,
    pub execution_path: Option<String>,
    pub quote_signature: String,
    pub is_winner: bool,
    pub received_at: DateTime<Utc>,
}

#[derive(Debug, Clone, FromRow)]
pub struct SlashRow {
    pub slash_id: Uuid,
    pub solver_id: Uuid,
    pub round_id: Uuid,
    pub reason: String,
    pub amount: String,
    pub slash_tx_hash: Option<String>,
    pub slashed_at: DateTime<Utc>,
}

/// Persistence boundary for the OFA subsystem. The API routes depend only on
/// this trait, so the transaction lifecycle can be swapped for a different
/// store in tests.
#[async_trait]
pub trait OpaStore: Send + Sync {
    // ── intents ────────────────────────────────────────────────────────────

    async fn create_intent(&self, intent: &NewIntent) -> Result<IntentRow, sqlx::Error>;

    async fn get_intent(&self, intent_id: Uuid) -> Result<Option<IntentRow>, sqlx::Error>;

    /// Compare-and-swap an intent status. Returns `true` when the transition
    /// happened (the intent was in `from_status`).
    async fn transition_intent_status(
        &self,
        intent_id: Uuid,
        from_status: IntentStatus,
        to_status: IntentStatus,
        cancel_reason: Option<&str>,
    ) -> Result<bool, sqlx::Error>;

    // ── solvers ────────────────────────────────────────────────────────────

    async fn create_solver(&self, solver: &NewSolver) -> Result<SolverRow, sqlx::Error>;

    async fn get_solver(&self, solver_id: Uuid) -> Result<Option<SolverRow>, sqlx::Error>;

    async fn list_active_solvers(
        &self,
        home_chain: Option<&str>,
    ) -> Result<Vec<SolverRow>, sqlx::Error>;

    // ── auction rounds ─────────────────────────────────────────────────────

    async fn open_round(
        &self,
        round_id: Uuid,
        intent_id: Uuid,
        closes_at: DateTime<Utc>,
    ) -> Result<Option<RoundRow>, sqlx::Error>;

    async fn get_round(&self, round_id: Uuid) -> Result<Option<RoundRow>, sqlx::Error>;

    async fn insert_quote(&self, quote: &NewQuote) -> Result<QuoteRow, sqlx::Error>;

    async fn list_round_quotes(&self, round_id: Uuid) -> Result<Vec<QuoteRow>, sqlx::Error>;

    /// Atomically close the round and commit the winner (guarded so only the
    /// first caller wins). Returns the selected quote on success.
    async fn select_winner(
        &self,
        round_id: Uuid,
        quote_id: Uuid,
        solver_id: Uuid,
    ) -> Result<Option<QuoteRow>, sqlx::Error>;

    async fn mark_round_settled(
        &self,
        round_id: Uuid,
        intent_id: Uuid,
        tx_hash: &str,
        chain: &str,
    ) -> Result<Option<RoundRow>, sqlx::Error>;

    // ── slashes ────────────────────────────────────────────────────────────

    async fn record_slash(
        &self,
        slash_id: Uuid,
        solver_id: Uuid,
        round_id: Uuid,
        reason: &str,
        amount: &str,
        slash_tx_hash: Option<&str>,
    ) -> Result<SlashRow, sqlx::Error>;
}

/// Postgres-backed [`OpaStore`] implementation.
#[derive(Debug, Clone)]
pub struct PgOpaStore {
    pool: PgPool,
}

impl PgOpaStore {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl OpaStore for PgOpaStore {
    async fn create_intent(&self, i: &NewIntent) -> Result<IntentRow, sqlx::Error> {
        sqlx::query_as::<_, IntentRow>(
            r#"
            INSERT INTO ofa_intents (
                intent_id, user_address, from_asset, from_asset_canonical,
                from_chain, from_amount, to_asset, to_asset_canonical,
                to_chain, to_address, deadline, min_output, signature, nonce, status
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, 'pending')
            RETURNING *
            "#,
        )
        .bind(i.intent_id)
        .bind(&i.user_address)
        .bind(&i.from_asset)
        .bind(&i.from_asset_canonical)
        .bind(&i.from_chain)
        .bind(&i.from_amount)
        .bind(&i.to_asset)
        .bind(&i.to_asset_canonical)
        .bind(&i.to_chain)
        .bind(&i.to_address)
        .bind(i.deadline)
        .bind(&i.min_output)
        .bind(&i.signature)
        .bind(i.nonce)
        .fetch_one(&self.pool)
        .await
    }

    async fn get_intent(&self, intent_id: Uuid) -> Result<Option<IntentRow>, sqlx::Error> {
        sqlx::query_as::<_, IntentRow>("SELECT * FROM ofa_intents WHERE intent_id = $1")
            .bind(intent_id)
            .fetch_optional(&self.pool)
            .await
    }

    async fn transition_intent_status(
        &self,
        intent_id: Uuid,
        from_status: IntentStatus,
        to_status: IntentStatus,
        cancel_reason: Option<&str>,
    ) -> Result<bool, sqlx::Error> {
        let res = sqlx::query(
            r#"
            UPDATE ofa_intents
            SET status = $1, cancel_reason = $2, updated_at = NOW()
            WHERE intent_id = $3 AND status = $4
            "#,
        )
        .bind(to_status.as_str())
        .bind(cancel_reason)
        .bind(intent_id)
        .bind(from_status.as_str())
        .execute(&self.pool)
        .await?;
        Ok(res.rows_affected() == 1)
    }

    async fn create_solver(&self, s: &NewSolver) -> Result<SolverRow, sqlx::Error> {
        sqlx::query_as::<_, SolverRow>(
            r#"
            INSERT INTO ofa_solvers (
                solver_id, name, home_chain, bond_address, bond_asset,
                bond_amount, api_key_hash
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *
            "#,
        )
        .bind(s.solver_id)
        .bind(&s.name)
        .bind(&s.home_chain)
        .bind(&s.bond_address)
        .bind(&s.bond_asset)
        .bind(&s.bond_amount)
        .bind(&s.api_key_hash)
        .fetch_one(&self.pool)
        .await
    }

    async fn get_solver(&self, solver_id: Uuid) -> Result<Option<SolverRow>, sqlx::Error> {
        sqlx::query_as::<_, SolverRow>("SELECT * FROM ofa_solvers WHERE solver_id = $1")
            .bind(solver_id)
            .fetch_optional(&self.pool)
            .await
    }

    async fn list_active_solvers(
        &self,
        home_chain: Option<&str>,
    ) -> Result<Vec<SolverRow>, sqlx::Error> {
        match home_chain {
            Some(chain) => {
                sqlx::query_as::<_, SolverRow>(
                    "SELECT * FROM ofa_solvers WHERE status = 'active' AND home_chain = $1",
                )
                .bind(chain)
                .fetch_all(&self.pool)
                .await
            }
            None => {
                sqlx::query_as::<_, SolverRow>(
                    "SELECT * FROM ofa_solvers WHERE status = 'active'",
                )
                .fetch_all(&self.pool)
                .await
            }
        }
    }

    async fn open_round(
        &self,
        round_id: Uuid,
        intent_id: Uuid,
        closes_at: DateTime<Utc>,
    ) -> Result<Option<RoundRow>, sqlx::Error> {
        let mut tx = self.pool.begin().await?;

        // Only a pending intent can open an auction — concurrent opens race on
        // this compare-and-swap and exactly one wins.
        let updated = sqlx::query(
            r#"
            UPDATE ofa_intents
            SET status = 'auction_open', updated_at = NOW()
            WHERE intent_id = $1 AND status = 'pending'
            "#,
        )
        .bind(intent_id)
        .execute(&mut *tx)
        .await?;

        if updated.rows_affected() != 1 {
            tx.commit().await?;
            return Ok(None);
        }

        let now = Utc::now();
        let row = sqlx::query_as::<_, RoundRow>(
            r#"
            INSERT INTO ofa_auction_rounds (round_id, intent_id, opened_at, closes_at, status)
            VALUES ($1, $2, $3, $4, 'open')
            RETURNING *
            "#,
        )
        .bind(round_id)
        .bind(intent_id)
        .bind(now)
        .bind(closes_at)
        .fetch_one(&mut *tx)
        .await?;

        tx.commit().await?;
        Ok(Some(row))
    }

    async fn get_round(&self, round_id: Uuid) -> Result<Option<RoundRow>, sqlx::Error> {
        sqlx::query_as::<_, RoundRow>("SELECT * FROM ofa_auction_rounds WHERE round_id = $1")
            .bind(round_id)
            .fetch_optional(&self.pool)
            .await
    }

    async fn insert_quote(&self, q: &NewQuote) -> Result<QuoteRow, sqlx::Error> {
        sqlx::query_as::<_, QuoteRow>(
            r#"
            INSERT INTO ofa_solver_quotes (
                quote_id, round_id, intent_id, solver_id,
                fill_amount, execution_path, quote_signature
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *
            "#,
        )
        .bind(q.quote_id)
        .bind(q.round_id)
        .bind(q.intent_id)
        .bind(q.solver_id)
        .bind(&q.fill_amount)
        .bind(&q.execution_path)
        .bind(&q.quote_signature)
        .fetch_one(&self.pool)
        .await
    }

    async fn list_round_quotes(&self, round_id: Uuid) -> Result<Vec<QuoteRow>, sqlx::Error> {
        sqlx::query_as::<_, QuoteRow>(
            "SELECT * FROM ofa_solver_quotes WHERE round_id = $1 ORDER BY received_at ASC",
        )
        .bind(round_id)
        .fetch_all(&self.pool)
        .await
    }

    async fn select_winner(
        &self,
        round_id: Uuid,
        quote_id: Uuid,
        solver_id: Uuid,
    ) -> Result<Option<QuoteRow>, sqlx::Error> {
        let mut tx = self.pool.begin().await?;

        let res = sqlx::query(
            r#"
            UPDATE ofa_auction_rounds
            SET status = 'closed',
                winner_solver_id = $1,
                winner_quote_id = $2,
                created_at = created_at
            WHERE round_id = $3 AND status = 'open'
            "#,
        )
        .bind(solver_id)
        .bind(quote_id)
        .bind(round_id)
        .execute(&mut *tx)
        .await?;

        if res.rows_affected() != 1 {
            tx.commit().await?;
            return Ok(None);
        }

        let quote = sqlx::query_as::<_, QuoteRow>(
            "UPDATE ofa_solver_quotes SET is_winner = TRUE WHERE quote_id = $1 RETURNING *",
        )
        .bind(quote_id)
        .fetch_one(&mut *tx)
        .await?;

        // Once a winner is picked the intent moves into the settlement phase.
        sqlx::query(
            r#"
            UPDATE ofa_intents
            SET status = 'auction_won', updated_at = NOW()
            WHERE intent_id = $1 AND status = 'auction_open'
            "#,
        )
        .bind(quote.intent_id)
        .execute(&mut *tx)
        .await?;

        tx.commit().await?;
        Ok(Some(quote))
    }

    async fn mark_round_settled(
        &self,
        round_id: Uuid,
        intent_id: Uuid,
        tx_hash: &str,
        chain: &str,
    ) -> Result<Option<RoundRow>, sqlx::Error> {
        let mut tx = self.pool.begin().await?;

        let row = sqlx::query_as::<_, RoundRow>(
            r#"
            UPDATE ofa_auction_rounds
            SET status = 'settled',
                settled_tx_hash = $1,
                settled_chain = $2,
                settled_at = NOW()
            WHERE round_id = $3 AND status IN ('closed', 'open')
            RETURNING *
            "#,
        )
        .bind(tx_hash)
        .bind(chain)
        .bind(round_id)
        .fetch_optional(&mut *tx)
        .await?;

        if row.is_some() {
            sqlx::query(
                r#"
                UPDATE ofa_intents
                SET status = 'filled', updated_at = NOW()
                WHERE intent_id = $1 AND status IN ('auction_open', 'auction_won')
                "#,
            )
            .bind(intent_id)
            .execute(&mut *tx)
            .await?;
        }

        tx.commit().await?;
        Ok(row)
    }

    async fn record_slash(
        &self,
        slash_id: Uuid,
        solver_id: Uuid,
        round_id: Uuid,
        reason: &str,
        amount: &str,
        slash_tx_hash: Option<&str>,
    ) -> Result<SlashRow, sqlx::Error> {
        sqlx::query_as::<_, SlashRow>(
            r#"
            INSERT INTO ofa_slash_events (slash_id, solver_id, round_id, reason, amount, slash_tx_hash)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
            "#,
        )
        .bind(slash_id)
        .bind(solver_id)
        .bind(round_id)
        .bind(reason)
        .bind(amount)
        .bind(slash_tx_hash)
        .fetch_one(&self.pool)
        .await
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn api_key_hashes_deterministically() {
        let a = hash_api_key("supersecret_key");
        let b = hash_api_key("supersecret_key");
        assert_eq!(a, b);
        assert_eq!(a.len(), 64);
        assert_ne!(a, hash_api_key("other"));
    }

    #[test]
    fn status_roundtrip_unknown_fails_closed() {
        assert!(IntentStatus::from_str("nope").is_none());
        assert_eq!(
            RoundStatus::from_str("bogus"),
            None
        );
    }
}